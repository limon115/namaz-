package com.example.bdprayer.ui;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.os.Handler;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.lifecycle.ViewModelProvider;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.example.bdprayer.R;
import com.example.bdprayer.viewmodel.PrayerViewModel;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class MainActivity extends AppCompatActivity {

    private PrayerViewModel viewModel;
    private TextView tvCountdown, tvLocation, tvSuhur, tvIftar;
    private Handler handler = new Handler();
    private Runnable countdownRunnable;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        tvCountdown = findViewById(R.id.tvCountdown);
        tvLocation = findViewById(R.id.tvLocation);
        tvSuhur = findViewById(R.id.tvSuhur);
        tvIftar = findViewById(R.id.tvIftar);

        viewModel = new ViewModelProvider(this).get(PrayerViewModel.class);

        RecyclerView rv = findViewById(R.id.rvPrayerTimes);
        rv.setLayoutManager(new LinearLayoutManager(this));

        checkPermissions();
        startCountdown();

        findViewById(R.id.btnSettings).setOnClickListener(v -> 
            startActivity(new Intent(this, SettingsActivity.class)));
        findViewById(R.id.btnProfile).setOnClickListener(v -> 
            startActivity(new Intent(this, ProfileActivity.class)));

        viewModel.getTodayPrayer().observe(this, prayer -> {
            if (prayer != null) {
                tvSuhur.setText(prayer.suhur);
                tvIftar.setText(prayer.iftar);
                // Update adapter logic here
            }
        });
    }

    private void startCountdown() {
        countdownRunnable = new Runnable() {
            @Override
            public void run() {
                // Logic to calculate diff between now and next iftar
                updateCountdownUI();
                handler.postDelayed(this, 1000);
            }
        };
        handler.post(countdownRunnable);
    }

    private void updateCountdownUI() {
        // Real implementation would calculate duration
        tvCountdown.setText(new SimpleDateFormat("HH'h 'mm'm 'ss's'", Locale.getDefault()).format(new Date()));
    }

    private void checkPermissions() {
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.ACCESS_FINE_LOCATION}, 100);
        }
    }
}