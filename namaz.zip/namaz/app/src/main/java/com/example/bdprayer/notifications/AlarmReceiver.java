package com.example.bdprayer.notifications;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import androidx.core.app.NotificationCompat;
import androidx.core.app.NotificationManagerCompat;
import com.example.bdprayer.R;

public class AlarmReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context context, Intent intent) {
        String prayerName = intent.getStringExtra("PRAYER_NAME");
        
        NotificationCompat.Builder builder = new NotificationCompat.Builder(context, "PRAYER_CHANNEL")
                .setSmallIcon(R.drawable.ic_notifications)
                .setContentTitle("Prayer Time")
                .setContentText("It's time for " + prayerName)
                .setPriority(NotificationCompat.PRIORITY_HIGH);

        NotificationManagerCompat notificationManager = NotificationManagerCompat.from(context);
        notificationManager.notify(1, builder.build());
    }
}