package com.example.bdprayer.model;

import androidx.room.Entity;
import androidx.room.PrimaryKey;

@Entity(tableName = "prayer_times")
public class PrayerTime {
    @PrimaryKey(autoGenerate = true)
    public int id;
    public String date;
    public String fajr;
    public String dhuhr;
    public String asr;
    public String maghrib;
    public String isha;
    public String suhur;
    public String iftar;
    public double latitude;
    public double longitude;
}