package com.example.bdprayer.network;

import retrofit2.Call;
import retrofit2.http.GET;
import retrofit2.http.Query;

public interface AladhanApi {
    @GET("v1/timings")
    Call<ApiResponse> getTimings(
        @Query("latitude") double lat,
        @Query("longitude") double lon,
        @Query("method") int method
    );
}