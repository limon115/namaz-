package com.example.bdprayer.viewmodel;

import android.app.Application;
import androidx.annotation.NonNull;
import androidx.lifecycle.AndroidViewModel;
import androidx.lifecycle.LiveData;
import com.example.bdprayer.model.PrayerTime;
import com.example.bdprayer.repository.PrayerRepository;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class PrayerViewModel extends AndroidViewModel {
    private PrayerRepository repository;
    private LiveData<PrayerTime> todayPrayer;

    public PrayerViewModel(@NonNull Application application) {
        super(application);
        repository = new PrayerRepository(application);
        String date = new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(new Date());
        todayPrayer = repository.getTodayPrayer(date);
    }

    public LiveData<PrayerTime> getTodayPrayer() {
        return todayPrayer;
    }
}