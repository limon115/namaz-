package com.example.bdprayer.database;

import android.content.Context;
import androidx.room.Database;
import androidx.room.Room;
import androidx.room.RoomDatabase;
import com.example.bdprayer.model.PrayerTime;
import com.example.bdprayer.model.UserProfile;

@Database(entities = {PrayerTime.class, UserProfile.class}, version = 1, exportSchema = false)
public abstract class AppDatabase extends RoomDatabase {
    private static AppDatabase instance;
    public abstract PrayerDao prayerDao();
    public abstract UserProfileDao userProfileDao();

    public static synchronized AppDatabase getInstance(Context context) {
        if (instance == null) {
            instance = Room.databaseBuilder(context.getApplicationContext(),
                    AppDatabase.class, "prayer_db")
                    .fallbackToDestructiveMigration()
                    .build();
        }
        return instance;
    }
}