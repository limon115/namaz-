package com.example.bdprayer.util;

public class Constants {
    public static final String BASE_URL = "https://api.aladhan.com/";
    public static final String PREFS_NAME = "BD_PRAYER_PREFS";
    public static final String KEY_DARK_MODE = "dark_mode";
    public static final String KEY_TIME_FORMAT_24 = "time_format_24";
    public static final String KEY_NOTIF_ENABLED = "notif_enabled";
}