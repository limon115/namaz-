package com.example.bdprayer.repository;

import android.app.Application;
import androidx.lifecycle.LiveData;
import com.example.bdprayer.database.AppDatabase;
import com.example.bdprayer.database.PrayerDao;
import com.example.bdprayer.model.PrayerTime;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class PrayerRepository {
    private PrayerDao prayerDao;
    private ExecutorService executorService;

    public PrayerRepository(Application application) {
        AppDatabase db = AppDatabase.getInstance(application);
        prayerDao = db.prayerDao();
        executorService = Executors.newFixedThreadPool(2);
    }

    public LiveData<PrayerTime> getTodayPrayer(String date) {
        return prayerDao.getPrayerByDate(date);
    }

    public void insert(PrayerTime prayerTime) {
        executorService.execute(() -> prayerDao.insert(prayerTime));
    }
}